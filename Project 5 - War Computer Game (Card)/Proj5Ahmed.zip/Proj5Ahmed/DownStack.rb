#Faizan Ahmed
#11/11/2015
#Project 5 - DownStack Class - inherits from Deck

# Downstack is the same as a Deck, except that a DownStack object is initially empty.
class DownStack < Deck
	
  def initialize
    @cards = []
  end
  
end