//Faizan Ahmed
//Project 6 - testing Visitor Class
//Nov 12, 2015

public class test1{
	
	public static void main(String[] args){
		
		//creating visitor object
		Visitor v = new Visitor("Alex Smirnov", 'M', 35, "Russia");
		System.out.println(v);
		
	}
}