require './visitor.rb'

p = Visitor.new 'Smirnov, Alex', 'M', 35, 'Russia'
print p, "\n"

